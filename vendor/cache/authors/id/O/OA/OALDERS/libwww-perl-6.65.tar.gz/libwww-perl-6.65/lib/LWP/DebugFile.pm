package LWP::DebugFile;

our $VERSION = '6.65';

# legacy stub

1;
